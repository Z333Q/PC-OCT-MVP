// src/components/Admin/OracleManagement.jsx

import React from 'react';

const OracleManagement = ({ data }) => {
  return (
    <div className="oracle-management">
      <h2>Oracle Management</h2>
      {/* Further functionality here */}
    </div>
  );
};

export default OracleManagement;
