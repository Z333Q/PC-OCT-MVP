// src/components/Admin/GameManagement.jsx

import React from 'react';

const GameManagement = ({ data }) => {
  return (
    <div className="game-management">
      <h2>Game Management</h2>
      {/* Further functionality here */}
    </div>
  );
};

export default GameManagement;
