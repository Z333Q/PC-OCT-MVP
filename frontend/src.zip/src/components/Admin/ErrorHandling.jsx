// src/components/Admin/ErrorHandling.jsx

import React from 'react';

const ErrorHandling = ({ data }) => {
  return (
    <div className="error-handling">
      <h2>Error Handling</h2>
      {/* Further functionality here */}
    </div>
  );
};

export default ErrorHandling;
